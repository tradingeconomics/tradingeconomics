=====================
Trading Economics API
=====================

Install Python
===============
If you don’t have a copy of Python installed on your computer, you can get it from:

 - https://www.python.org/downloads/ 


Install pip
============

You can find all information in: 

 - https://packaging.python.org/installing/ 

Check our docs on how to use the package 
----------------------------------------


 - https://docs.tradingeconomics.com/#introduction 

 - https://github.com/ieconomics/open-api/tree/master/python 
