Python version of Trading Economics API library.
