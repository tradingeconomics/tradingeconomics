from historical import getHistoricalData
from calendar import getCalendarData
from forecasts import getForecastData
from indicators import getIndicatorData
from markets import getMarketsData