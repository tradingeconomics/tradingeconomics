import json 
import urllib 
import pandas as pd
from datetime import *
import re
import itertools


def credCheck(credentials):
    pattern = re.compile("^...............:...............$")
    if pattern.match(credentials):
        print("Correct credentials format")
    else:
        raise ValueError('Incorrect credentials format')


def getMarketsData(marketsField, output_type = None, credentials = None):
    fields =['commodities', 'currency', 'index', 'bonds']
    if marketsField not in fields:
        raise ValueError ('Possible values for marketsField are commodities, currency, index or bonds')
    linkAPI = 'http://api.tradingeconomics.com/markets/' + urllib.quote(marketsField) 
    if credentials == None:
        credentials = 'guest:guest'
    else:
        credCheck(credentials)
    linkAPI = linkAPI + '?c=' + credentials
    webResults = json.load(urllib.urlopen(linkAPI))
    names = ['name', 'date', 'last', 'group']
    names2 = ['Name', 'Date', 'Last', 'Group']
    maindf = pd.DataFrame()     
    for i in range(len(names)):
        names[i] =  [d[names2[i]] for d in webResults]
        maindf = pd.concat([maindf, pd.DataFrame(names[i], columns = [names2[i]])], axis = 1)
    if output_type == None or output_type =='df':        
        output = maindf.dropna()
    elif output_type == 'raw':        
        output = webResults
    else:      
        raise ValueError ('output_type options : df(defoult) for data frame or raw for results directly from web.') 
    return output
    
