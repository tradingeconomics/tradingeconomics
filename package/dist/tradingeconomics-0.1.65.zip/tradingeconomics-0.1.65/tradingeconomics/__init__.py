from historical import getHistoricalData
from calendar import getCalendarData
from forecasts import getForecastData
from indicators import getIndicatorData
from markets import getMarketsData

"""This package was developed strictly for Trading Economics website users."""

"""

Function getHistoricalData extract historical data from Trading Economics website.
:param country: The name of the country
:param indicator: The name of the indicator
:param initDate: Date since whem data is extracted
:param endDate: Date when extracting is stoped
:param output_type: 'dict' return a dictionary (by defoult), 'df' return a data frame, 'raw' return list of dictionaries directly from browser
:param credentials: User's credentials.

""" 

#Do you work ??? 