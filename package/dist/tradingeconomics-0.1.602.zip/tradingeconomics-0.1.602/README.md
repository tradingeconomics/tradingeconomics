"""
some text ..
explanation of package
"""